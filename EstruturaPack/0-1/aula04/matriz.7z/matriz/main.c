#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  
         int matriz [4][4]={{1,2,3,4},{1,2,3,4}};
         int x,y;
         int soma;
         int a,b,c;         

         for (x=0; x<=4; x++)
  {
         for(y=0; y<=4; y++)
      {
     
         if (x>y) soma = soma +matriz [x] [y];
      } 
        printf("a soma da matriz %d\n", soma);
}    
        if (x==y)
      {
        soma=soma+matriz [x][y];
        printf("a soma da diagonal e: %d\n", soma);
      }
        if (c= a+b);
      {
        soma = soma+matriz[x][y];
        printf("a soma da duas matrizes e: %d\n", c);
  
}
  system("PAUSE");	
  return 0;
}
